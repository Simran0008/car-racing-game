import pygame
import random

# Initialize Pygame
pygame.init()

# Set up the game window
WINDOW_WIDTH = 800
WINDOW_HEIGHT = 600
game_window = pygame.display.set_mode((WINDOW_WIDTH, WINDOW_HEIGHT))
pygame.display.set_caption("Car Racing Game")

# Define colors
BLACK = (0, 0, 0)
WHITE = (255, 255, 255)
RED = (255, 0, 0)
GREEN = (0, 255, 0)

# Define game objects
class Player(pygame.sprite.Sprite):
    def __init__(self):
        super().__init__()
        self.image = pygame.image.load(r"C:\Users\admin\Downloads\jeff\player_car.JPG")
        self.rect = self.image.get_rect()
        self.rect.x = WINDOW_WIDTH // 2
        self.rect.y = WINDOW_HEIGHT - 100
        self.speed = 5

    def update(self):
        keys = pygame.key.get_pressed()
        if keys[pygame.K_LEFT] and self.rect.x > 0:
            self.rect.x -= self.speed
        if keys[pygame.K_RIGHT] and self.rect.x < WINDOW_WIDTH - self.rect.width:
            self.rect.x += self.speed
        if keys[pygame.K_UP] and self.rect.y > 0:
            self.rect.y -= self.speed
        if keys[pygame.K_DOWN] and self.rect.y < WINDOW_HEIGHT - self.rect.height:
            self.rect.y += self.speed

class Coin(pygame.sprite.Sprite):
    def __init__(self):
        super().__init__()
        self.image = pygame.image.load(r"C:\Users\admin\Downloads\jeff\coin.JPG")
        self.rect = self.image.get_rect()
        self.rect.x = random.randint(0, WINDOW_WIDTH - self.rect.width)
        self.rect.y = random.randint(0, WINDOW_HEIGHT - self.rect.height)

class Enemy(pygame.sprite.Sprite):
    def __init__(self):
        super().__init__()
        self.image = pygame.image.load(r"C:\Users\admin\Downloads\jeff\enemy_car.JPG")
        self.rect = self.image.get_rect()
        self.rect.x = random.randint(0, WINDOW_WIDTH - self.rect.width)
        self.rect.y = random.randint(-200, -50)
        self.speed = random.randint(1, 7)

    def update(self):
        self.rect.y += self.speed
        if self.rect.top > WINDOW_HEIGHT:
            self.rect.x = random.randint(0, WINDOW_WIDTH - self.rect.width)
            self.rect.y = random.randint(-200, -50)
            self.speed = random.randint(3, 7)

def main():
    start_button = pygame.Rect(300, 200, 200, 50)
    start_font = pygame.font.Font(None, 36)
    start_text = start_font.render("Start", True, BLACK)

    player = Player()
    coins = pygame.sprite.Group()
    enemies = pygame.sprite.Group()
    score = 0
    clock = pygame.time.Clock()
    running = False
    game_over = False

    while not running:
        game_window.fill(WHITE)
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                return
            if event.type == pygame.MOUSEBUTTONDOWN:
                mouse_pos = event.pos
                if start_button.collidepoint(mouse_pos):
                    running = True

        pygame.draw.rect(game_window, GREEN, start_button)
        game_window.blit(start_text, (345, 210))
        pygame.display.flip()

    # Create initial coins and enemies
    for _ in range(10):
        coins.add(Coin())
        enemies.add(Enemy())

    while running:
        clock.tick(60)
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

        # Update game objects if not game over
        if not game_over:
            player.update()
            coins.update()
            enemies.update()

            # Check for collisions
            coin_collected = pygame.sprite.spritecollide(player, coins, True)
            if coin_collected:
                score += len(coin_collected)
            enemy_collision = pygame.sprite.spritecollide(player, enemies, False)
            if enemy_collision:
                game_over = True

        # Draw the game objects
        game_window.fill(WHITE)
        if not game_over:
            game_window.blit(player.image, player.rect)
            coins.draw(game_window)
            enemies.draw(game_window)
        else:
            game_over_text = start_font.render("Game Over", True, RED)
            game_window.blit(game_over_text, (WINDOW_WIDTH // 2 - 80, WINDOW_HEIGHT // 2))
            restart_button = pygame.Rect(300, 300, 200, 50)
            pygame.draw.rect(game_window, GREEN, restart_button)
            restart_text = start_font.render("Restart", True, BLACK)
            game_window.blit(restart_text, (340, 310))
            pygame.display.flip()
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    running = False
                if event.type == pygame.MOUSEBUTTONDOWN and game_over:
                    mouse_pos = event.pos
                    if restart_button.collidepoint(mouse_pos):
                        main()

        # Display the score
        font = pygame.font.Font(None, 36)
        score_text = font.render(f"Score: {score}", True, BLACK)
        game_window.blit(score_text, (10, 10))

        pygame.display.flip()

    pygame.quit()

if __name__ == "__main__":
    main()
